package hw1;

public class BadOperationException extends RuntimeException {
    // TODO HW1 P2
    public BadOperationException(String errorMessage) {
            super(errorMessage);
    }
}

